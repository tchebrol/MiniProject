package com.cg.miniproject.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.service.IHotelBookingService;
import com.cg.miniproject.service.HotelBookingServiceImpl;

public class Client {

	public static void main(String[] args) {

		User user = new User();
		IHotelBookingService ireg = new HotelBookingServiceImpl();
		boolean result = false;
		;
		Scanner sc = new Scanner(System.in);

		System.out.println("Choose your category :\n");
		System.out.println("1.User\n" + "2.Employee\n" + "3.Admin");
		int choice = sc.nextInt();
		if (choice == 1) {
			user.setRole("User");
			System.out.println("-------------------------------");
			System.out.println("You want to Register or Login?");
			System.out.println("1.Register\t" + "2.Login");
			int choice2 = sc.nextInt();
			switch (choice2) {
			case 1:
				User user2 = new User();
				user2.setRole(user.getRole());
				System.out.println("Enter Username :");
				user2.setUserName(sc.next());
				System.out.println("Enter Password :");
				user2.setPassword(sc.next());
				System.out.println("Enter MobileNo :");
				user2.setMobileNo(sc.next());
				System.out.println("Enter Phone :");
				user2.setPhone(sc.next());
				System.out.println("Enter Address :");
				user2.setAddress(sc.next());
				System.out.println("Enter Email :");
				user2.setEmail(sc.next());
				result = ireg.register(user2);
				if (result) {

					System.out.println("Registration successfull !!!");
				} else {
					System.out.println("Registration Failed !!!");
				}
				break;

			case 2:
				System.out.println("Enter Username :");
				user.setUserName(sc.next());
				System.out.println("Enter Password :");
				user.setPassword(sc.next());
				result = ireg.login(user);
				if (result) {

					// System.out.println("Login Successfull !!!");

					Hotel hotel = new Hotel();

					IHotelBookingService service = new HotelBookingServiceImpl();
					int ch = -1;
					while (ch != 4) {
						System.out.println("-------------------------------");
						System.out.println("Select your choice");
						System.out.println("1.View List of Hotels.\n2.Book a room.\n3.exit");
						Scanner scanner = new Scanner(System.in);
						ch = scanner.nextInt();
						switch (ch) {
						case 1:
							System.out.println("-------------------------------");
							System.out.println("List Of Hotels:");

							ArrayList<Hotel> list = new ArrayList<Hotel>();
							list = service.getHotelList();
							if (!list.isEmpty()) {
								int i = 1;

								for (Hotel hotel2 : list) {
									System.out.println(i + "." + hotel2.getHotelId() + "-" + hotel2.getCity() + "-"
											+ hotel2.getHotelName());
									i++;
								}
							}
							break;
						case 2:
							System.out.println("Enter hotel Id:");
							String id = sc.next();
							ArrayList<RoomDetails> details = service.getRoomDetails(id);
							if (!details.isEmpty()) {
								System.out.println("-------------------------------");
								System.out.println("Available Room Details");
								for (RoomDetails roomDetails : details) {
									System.out.println("Hotel Id : " + roomDetails.getHotelId() + "\nRoom Id : "
											+ roomDetails.getRoomId() + "\nRoom No : " + roomDetails.getRoomNo()
											+ "\nRoom Type : " + roomDetails.getRoomType() + "\nPer Night Rate"
											+ roomDetails.getPerNightRate() + "\nAvailability"
											+ roomDetails.getAvailability());
								}
								BookingDetails bookingDetails=new BookingDetails();
								System.out.println("-------------------------------");
								System.out.println("Enter room id:");
								bookingDetails.setRoomId(sc.next());
								System.out.println("Enter Starting date in dd/MM/yyyy format:");
								bookingDetails.setBookedFrom(sc.next());
								
								System.out.println("Enter Ending date in dd/MM/yyyy format:");
								bookingDetails.setBookedTo(sc.next());
								
								System.out.println("Enter no of adults:");
								bookingDetails.setNoOfAdults(sc.nextInt());
								System.out.println("Enter no of children:");
								bookingDetails.setNoOfChildren(sc.nextInt());
								service.insertBookingDetails(bookingDetails);
							} else {
								System.out.println("Rooms not available");
							}
							break;
						default:
							
							break;
						}
					}

				} else {
					System.out.println("Login Failed !!!Please Login Again");
				}
				break;
			default:
				System.out.println("Invalid option");
			}
		} else if (choice == 2) {
			user.setRole("Employee");
			System.out.println("-------------------------------");
			System.out.println("Do you want to Register or Login?");
			System.out.println("1.Register" + "2.Login");
			int choice2 = sc.nextInt();
			switch (choice2) {
			case 1:
				User user2 = new User();
				user2.setRole(user.getRole());
				System.out.println("Enter Username :");
				user2.setUserName(sc.next());
				System.out.println("Enter Password :");
				user2.setPassword(sc.next());
				System.out.println("Enter MobileNo :");
				user2.setMobileNo(sc.next());
				System.out.println("Enter Phone :");
				user2.setPhone(sc.next());
				System.out.println("Enter Address :");
				user2.setAddress(sc.next());
				System.out.println("Enter Email :");
				user2.setEmail(sc.next());
				result = ireg.register(user2);
				if (result) {

					System.out.println("Registration successfull !!!");
				} else {
					System.out.println("Registration Failed !!!");
				}
				break;

			case 2:
				System.out.println("Enter Username :");
				user.setUserName(sc.next());
				System.out.println("Enter Password :");
				user.setPassword(sc.next());
				result = ireg.login(user);
				if (result) {

					System.out.println("Login Successfull !!!");
				} else {
					System.out.println("Login Failed !!!Please Login Again");
				}
				break;
			default:
				System.out.println("Invalid option");
			}

		} else if (choice == 3) {
			user.setRole("Admin");
			System.out.println("Enter Username :");
			user.setUserName(sc.next());
			System.out.println("Enter Password :");
			user.setPassword(sc.next());
			result = ireg.login(user);
			if (result) {
				Hotel hotel = new Hotel();
				RoomDetails roomDetails = new RoomDetails();
				IHotelBookingService service = new HotelBookingServiceImpl();
				int ch = -1;
				while (ch != 4) {
					System.out.println("-------------------------------");
					System.out.println("Select your choice");
					System.out.println(
							"1.Perform Hotel Management.\n2.Perform Room Management.\n3.View Reports.\n4.exit");
					Scanner scanner = new Scanner(System.in);
					ch = scanner.nextInt();
					switch (ch) {
					case 1:
						System.out.println("Select your choice");
						System.out.println("\n1.Add Hotels.\n2.Delete Hotels");

						int choice1 = scanner.nextInt();
						if (choice1 == 1) {
							System.out.println("please enter hotel id");
							hotel.setHotelId(scanner.next());
							System.out.println("Please enter hotel name");
							hotel.setHotelName(scanner.next());
							System.out.println("please enter city name");
							hotel.setCity(scanner.next());
							System.out.println("please enter avg rate per night");
							hotel.setAvgRatePerNight(scanner.nextDouble());
							System.out.println("please enter description");
							hotel.setDescription(scanner.next());
							System.out.println("please enter Address");
							hotel.setAddress(scanner.next());
							result = service.addHotels(hotel);
							if (result)
								System.out.println("Added Hotel Successfully");

						} else if (choice1 == 2) {
							System.out.println("Please enter hotel id to delete hotel details");
							String id = scanner.next();
							result = service.deleteHotel(id);
							if (result)
								System.out.println("Deleted Hotel Successfully");
						}

						break;
					case 2:

						System.out.println("Select your choice");
						System.out.println("\n1.Add Rooms.\n2.Delete Rooms");

						int choice2 = scanner.nextInt();
						if (choice2 == 1) {
							System.out.println("please enter hotel id");
							roomDetails.setHotelId(scanner.next());
							System.out.println("Please enter Room id");
							roomDetails.setRoomId(scanner.next());
							System.out.println("please enter Room no");
							roomDetails.setRoomNo(scanner.next());
							Scanner scanner4 = new Scanner(System.in);
							System.out.println("please enter room type");
							roomDetails.setRoomType(scanner4.nextLine());
							Scanner scanner2 = new Scanner(System.in);
							System.out.println("please enter rate per night");
							roomDetails.setPerNightRate(scanner2.nextDouble());

							System.out.println("please enter Availability");
							roomDetails.setAvailability(scanner2.next());
							result = service.addRooms(roomDetails);
							if (result)
								System.out.println("Added Room Details Successfully");

						} else if (choice2 == 2) {
							System.out.println("Please enter room id to delete room details");
							String id = scanner.next();
							result = service.deleteRoom(id);
							if (result)
								System.out.println("Deleted Room Successfully");
						}
						break;
					case 3:
						System.out.println("-------------------------------");
						System.out.println("Please select your choice");
						System.out.println(
								"1.View List of Hotels.\n2.View Bookings of specific hotel.\n3.View guest list of specific hotel.\n4.View bookings for specified date");
						Scanner scanner3 = new Scanner(System.in);
						int choice3 = scanner3.nextInt();
						if (choice3 == 1) {
							System.out.println("-------------------------------");
							System.out.println("List Of Hotels:");

							ArrayList<Hotel> list = new ArrayList<Hotel>();
							list = service.getHotelList();
							if (!list.isEmpty()) {
								int i = 1;

								for (Hotel hotel2 : list) {
									System.out.println(i + "." + hotel2.getHotelId() + "-" + hotel2.getCity() + "-"
											+ hotel2.getHotelName());
									i++;
								}
							}

						}
						if (choice3 == 2) {
							ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
							System.out.println("Please enter hotel id to retrieve bookings");
							String hotelId = scanner3.next();
							// System.out.println(hotelId);
							list = service.retrieveBookings(hotelId);
							System.out.println("-------------------------------");
							System.out.println("Booking Details");
							for (BookingDetails b : list)

								System.out.println("Booking Id: " + b.getBookingId() + "\nRoom Id: " + b.getRoomId()
										+ "\nUser Id: " + b.getUserId() + "\nBooked From: " + b.getBookedFrom()
										+ "\nBooked To: " + b.getBookedTo() + "\nNo of Adults" + b.getNoOfAdults()
										+ "\nNo of Children" + b.getNoOfChildren() + "\nAmount" + b.getAmount());
						}

						else if (choice3 == 4) {
							ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
							System.out.println("Enter a date in dd/MM/yyyy format to retrieve booking details");
							String date = scanner3.next();

							DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
							LocalDate date1 = LocalDate.parse(date, dtf);
							list = service.retrieveBookings(date1);
							
							System.out.println("-------------------------------");
							System.out.println("Booking Details");
							for (BookingDetails b : list)

								System.out.println("Booking Id: " + b.getBookingId() + "\nRoom Id: " + b.getRoomId()
										+ "\nUser Id: " + b.getUserId() + "\nBooked From: " + b.getBookedFrom()
										+ "\nBooked To: " + b.getBookedTo() + "\nNo of Adults" + b.getNoOfAdults()
										+ "\nNo of Children" + b.getNoOfChildren() + "\nAmount" + b.getAmount());

						}

						break;
					case 4:
						System.exit(0);
					default:
						break;
					}
				}

			} else {
				System.out.println("Login Failed !!!Please Login Again");
			}
		}

	}
}
