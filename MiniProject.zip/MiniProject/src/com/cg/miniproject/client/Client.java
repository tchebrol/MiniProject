package com.cg.miniproject.client;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;
import com.cg.miniproject.service.IHotelBookingService;
import com.cg.miniproject.service.HotelBookingServiceImpl;
import com.cg.miniproject.service.ServiceValidation;

public class Client {

	public static void main(String[] args) throws HotelException {

		User user = new User();
		User user3 = new User();
		IHotelBookingService hotelBookingService = new HotelBookingServiceImpl();
		ServiceValidation validation = new ServiceValidation();
		boolean result = false;

		Scanner scanner = new Scanner(System.in);
		System.out
				.println("****************Hotel Booking Management System*********************");
		try {
			System.out.println("---Choose your category---");
			System.out.println("1.User\n" + "2.Employee\n" + "3.Admin");
			int choice = scanner.nextInt();
			/*
			 * If role is User / Employee
			 */
			if (choice == 1 || choice == 2) {
				int option = -1;
				do {
					if (choice == 1)
						user.setRole("User");
					else
						user.setRole("Employee");
					System.out.println("-------------------------------");
					System.out.println("---You want to Register or Login?---");
					System.out.println("1.Register" + "\n2.Login");
					int choice2 = scanner.nextInt();
					switch (choice2) {
					/*
					 * Registration for user/employee
					 */
					case 1:

						User user2 = new User();
						user2.setRole(user.getRole());
						int j = 0;
						Scanner scanner2 = new Scanner(System.in);
						while (j >= 0) {
							System.out.println("\nEnter Username :");
							user2.setUserName(scanner2.nextLine());
							boolean res = hotelBookingService
									.validateName(user2);
							if (res) {
								System.err
										.println("Name already exists please enter another username");
							} else {
								break;
							}
							j++;
						}
						System.out.println("Enter Password :");
						user2.setPassword(scanner2.nextLine());
						System.out.println("Enter MobileNo :");

						user2.setMobileNo(scanner2.nextLine());
						j = validation.validateMobNo(user2.getMobileNo());
						while (j == 0) {
							System.out.println("Enter MobileNo :");
							user2.setMobileNo(scanner2.nextLine());
							j = validation.validateMobNo(user2.getMobileNo());
							if (j == 0) {
								System.err.println("Enter valid mobile number");
							} else {
								break;
							}
							j++;
						}
						System.out.println("Enter Phone :");
						user2.setPhone(scanner2.nextLine());
						j = validation.validatePhone(user2.getPhone());
						while (j == 0) {
							System.out.println("Enter Phone :");
							user2.setPhone(scanner2.nextLine());
							j = validation.validatePhone(user2.getPhone());
							if (j == 0) {
								System.err.println("Enter valid Phone number");
							} else {
								break;
							}
							j++;
						}
						validation.validatePhone(user2.getPhone());
						System.out.println("Enter Address :");
						user2.setAddress(scanner2.nextLine());
						System.out.println("Enter Email id :");
						user2.setEmail(scanner2.nextLine());
						j = validation.validateEmail(user2.getEmail());
						while (j == 0) {
							System.out.println("Enter Email id :");
							user2.setEmail(scanner2.nextLine());
							j = validation.validateEmail(user2.getEmail());
							if (j == 0) {
								System.err.println("Enter valid Email id");
							} else {
								break;
							}
							j++;
						}

						result = hotelBookingService.register(user2);
						if (result) {

							System.out.println("Registration successfull !!!");
						} else {
							System.out.println("Registration Failed !!!");
						}

						break;

					/*
					 * Login for user/employee
					 */
					case 2:
						System.out.println("Enter Username :");
						user.setUserName(scanner.next());
						System.out.println("Enter Password :");
						user.setPassword(scanner.next());
						result = hotelBookingService.login(user);

						if (result) {
							option = 0;
							user3 = hotelBookingService.fetchUserId(user);

							Hotel hotel = new Hotel();

							IHotelBookingService service = new HotelBookingServiceImpl();
							int ch = -1;
							/*
							 * Menu displayed for user after login
							 */
							while (ch != 4) {
								System.out
										.println("-------------------------------");
								System.out.println("---Select your choice---");
								System.out
										.println("1.View List of Hotels.\n2.Book a room.\n3.Check Booking Status.\n4.exit");
								Scanner scanner1 = new Scanner(System.in);
								ch = scanner1.nextInt();
								switch (ch) {
								/*
								 * List of hotels
								 */
								case 1:
									System.out
											.println("-------------------------------");
									System.out.println("---List Of Hotels---");

									ArrayList<Hotel> list = new ArrayList<Hotel>();
									list = service.getHotelList();
									if (!list.isEmpty()) {
										int i = 1;

										for (Hotel hotel2 : list) {
											System.out.println(i + "."
													+ hotel2.getHotelId() + "-"
													+ hotel2.getCity() + "-"
													+ hotel2.getHotelName());
											i++;
										}
									}
									break;
								/*
								 * Booking a room
								 */
								case 2:
									System.out.println("Enter hotel Id:");
									String id = scanner.next();
									ArrayList<RoomDetails> details = service
											.getRoomDetails(id);
									if (!details.isEmpty()) {
										System.out
												.println("-------------------------------");
										System.out
												.println("---Available Room Details---");
										for (RoomDetails roomDetails : details) {
											System.out
													.println("-------------------------------");
											System.out.println("Hotel Id : "
													+ roomDetails.getHotelId()
													+ "\nRoom Id : "
													+ roomDetails.getRoomId()
													+ "\nRoom No : "
													+ roomDetails.getRoomNo()
													+ "\nRoom Type : "
													+ roomDetails.getRoomType()
													+ "\nPer Night Rate : "
													+ roomDetails
															.getPerNightRate()
													+ "\nAvailability : "
													+ roomDetails
															.getAvailability());
										}
										BookingDetails bookingDetails = new BookingDetails();
										System.out
												.println("-------------------------------");
										System.out.println("Enter room id:");
										bookingDetails
												.setRoomId(scanner.next());
										System.out
												.println("Enter Starting date in dd/MM/yyyy format:");
										bookingDetails.setBookedFrom(scanner
												.next());

										System.out
												.println("Enter Ending date in dd/MM/yyyy format:");
										bookingDetails.setBookedTo(scanner
												.next());

										System.out
												.println("Enter no of adults:");
										bookingDetails.setNoOfAdults(scanner
												.nextInt());
										System.out
												.println("Enter no of children:");
										bookingDetails.setNoOfChildren(scanner
												.nextInt());
										bookingDetails.setUserId(user3
												.getUserId());
										boolean result1 = service
												.insertBookingDetails(bookingDetails);
										if (result1)
											System.out
													.println("Booked room successfully");
									} else {
										System.out
												.println("Rooms not available");
									}
									break;
								/*
								 * Check booking status
								 */
								case 3:

									BookingDetails details2 = new BookingDetails();
									details2.setUserId(user3.getUserId());
									boolean res = hotelBookingService
											.bookingStatus(details2);
									if (res) {
										System.out.println("Booking Confirmed");
									} else {
										System.out.println("Not yet booked");
									}
									break;
								case 4:
									break;
								}
							}

						} else {
							System.out
									.println("Login Failed !!!Please Login Again");
						}
						break;
					default:
						System.out.println("Invalid option");
					}
				} while (option != 0);
			} else if (choice == 3) {
				/*
				 * Admin login
				 */
				user.setRole("Admin");
				System.out.println("Enter Username :");
				user.setUserName(scanner.next());
				System.out.println("Enter Password :");
				user.setPassword(scanner.next());
				result = hotelBookingService.login(user);
				if (result) {
					Hotel hotel = new Hotel();
					RoomDetails roomDetails = new RoomDetails();
					IHotelBookingService service = new HotelBookingServiceImpl();
					int ch = -1;
					while (ch != 4) {
						System.out.println("-------------------------------");
						System.out.println("---Select your choice---");
						System.out
								.println("1.Perform Hotel Management.\n2.Perform Room Management.\n3.View Reports.\n4.exit");
						Scanner scanner1 = new Scanner(System.in);
						ch = scanner1.nextInt();
						switch (ch) {
						/*
						 * Perform Hotel management
						 */
						case 1:
							System.out.println("---Select your choice---");
							System.out
									.println("\n1.Add Hotels.\n2.Delete Hotels.\n3.Modify Hotels");

							int choice1 = scanner.nextInt();
							if (choice1 == 1) {
								int k = 0;
								while (k >= 0) {
									System.out.println("please enter hotel id");
									String id = scanner.next();
									boolean res = validation
											.validateHotelId(id);
									if (res) {
										hotel.setHotelId(id);
										break;
									}
									k++;
								}
								System.out.println("Please enter hotel name");
								hotel.setHotelName(scanner.next());
								System.out.println("Please enter city name");
								hotel.setCity(scanner.next());
								System.out
										.println("Please enter avg rate per night");
								hotel.setAvgRatePerNight(scanner.nextDouble());
								System.out.println("Please enter description");
								hotel.setDescription(scanner.next());
								System.out.println("please enter Address");
								Scanner scanner2 = new Scanner(System.in);
								hotel.setAddress(scanner2.nextLine());
								result = service.addHotels(hotel);
								if (result)
									System.out
											.println("Added Hotel Successfully");

							} else if (choice1 == 2) {
								System.out
										.println("Please enter hotel id to delete hotel details");
								String id = scanner.next();
								result = service.deleteHotel(id);
								if (result)
									System.out
											.println("Deleted Hotel Successfully");
							} else if (choice1 == 3) {
								Hotel hotel2 = new Hotel();
								System.out
										.println("Please enter hotel id to modify hotel details");
								hotel2.setHotelId(scanner.next());
								System.out
										.println("Please enter average rate per night");
								hotel2.setAvgRatePerNight(scanner.nextDouble());
								System.out.println("Please enter rating");
								Scanner scanner2 = new Scanner(System.in);
								hotel2.setRating(scanner2.next());
								result = service.modifyHotel(hotel2);
								if (result)
									System.out
											.println("Modified Hotel Successfully");
							}
							break;
						case 2:
							/*
							 * Perform Room management
							 */
							System.out.println("---Select your choice---");
							System.out
									.println("\n1.Add Rooms.\n2.Delete Rooms.\n3.Modify Rooms.");

							int choice2 = scanner.nextInt();
							if (choice2 == 1) {
								int k = 0;
								while (k >= 0) {
									System.out.println("please enter hotel id");
									String hotelId = scanner.next();
									hotel.setHotelId(hotelId);
									boolean res = hotelBookingService
											.validateHotelId(hotel);
									if (res) {
										roomDetails.setHotelId(hotelId);
										break;
									} else {
										System.err
												.println("Check out with hotel id");
									}
									k++;
								}

								int a = 0;
								while (a >= 0) {
									System.out.println("Please enter Room id");
									String id = scanner.next();
									boolean res = validation.validateRoomId(id);
									if (res) {
										roomDetails.setRoomId(id);
										break;
									}
									a++;
								}

								System.out.println("please enter Room no");
								roomDetails.setRoomNo(scanner.next());
								Scanner scanner4 = new Scanner(System.in);
								int i = 0;
								while (i >= 0) {
									System.out
											.println("please enter room type");
									String name = scanner4.nextLine();
									boolean res = validation.getRoomType(name);
									if (res) {
										roomDetails.setRoomType(name);
										break;
									}
									i++;
								}

								Scanner scanner2 = new Scanner(System.in);
								System.out
										.println("please enter rate per night");
								roomDetails.setPerNightRate(scanner2
										.nextDouble());

								System.out.println("please enter Availability");
								roomDetails.setAvailability(scanner2.next());
								result = service.addRooms(roomDetails);
								if (result)
									System.out
											.println("Added Room Details Successfully");

							} else if (choice2 == 2) {
								System.out
										.println("Please enter room id to delete room details");
								String id = scanner.next();
								result = service.deleteRoom(id);
								if (result)
									System.out
											.println("Deleted Room Successfully");
							} else if (choice2 == 3) {
								RoomDetails details = new RoomDetails();
								int k = 0;
								while (k >= 0) {
									System.out
											.println("Please enter hotel id to modify Room details");
									String hotelId = scanner.next();
									Hotel hotel2 = new Hotel();
									hotel2.setHotelId(hotelId);
									boolean res = hotelBookingService
											.validateHotelId(hotel2);
									if (res) {
										details.setHotelId(hotelId);
										break;
									} else {
										System.err
												.println("Check out with hotel id");
									}
									k++;
								}
								int a = 0;
								while (a >= 0) {
									System.out.println("Please enter Room id");
									String id = scanner.next();
									boolean res = validation.validateRoomId(id);
									if (res) {
										details.setRoomId(id);
										break;
									}
									a++;
								}

								System.out
										.println("Please enter rate per night");
								Scanner scanner2 = new Scanner(System.in);
								details.setPerNightRate(scanner.nextDouble());
								result = service.modifyRoom(details);
								if (result)
									System.out
											.println("Modified Room Successfully");
							}
							break;
						case 3:
							/*
							 * View Reports
							 */
							System.out
									.println("-------------------------------");
							System.out
									.println("---Please select your choice---");
							System.out
									.println("1.View List of Hotels.\n2.View Bookings of specific hotel.\n3.View guest list of specific hotel.\n4.View bookings for specified date");
							Scanner scanner3 = new Scanner(System.in);
							int choice3 = scanner3.nextInt();
							if (choice3 == 1) {
								System.out
										.println("-------------------------------");
								System.out.println("---List Of Hotels---");

								ArrayList<Hotel> list = new ArrayList<Hotel>();
								list = service.getHotelList();
								if (!list.isEmpty()) {
									int index = 1;

									for (Hotel hotel2 : list) {
										System.out.println(index + "."
												+ hotel2.getHotelId() + "-"
												+ hotel2.getCity() + "-"
												+ hotel2.getHotelName());
										index++;
									}
								}

							}
							if (choice3 == 2) {
								ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
								System.out
										.println("Please enter hotel id to retrieve bookings");
								String hotelId = scanner3.next();
								list = service.retrieveBookings(hotelId);
								System.out
										.println("-------------------------------");
								System.out.println("---Booking Details---");
								for (BookingDetails b : list) {
									System.out
											.println("-------------------------------");
									System.out.println("Booking Id: "
											+ b.getBookingId() + "\nRoom Id: "
											+ b.getRoomId() + "\nUser Id: "
											+ b.getUserId() + "\nBooked From: "
											+ b.getBookedFrom()
											+ "\nBooked To: " + b.getBookedTo()
											+ "\nNo of Adults: "
											+ b.getNoOfAdults()
											+ "\nNo of Children: "
											+ b.getNoOfChildren()
											+ "\nAmount: " + b.getAmount());
								}
							}

							else if (choice3 == 3) {
								ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
								System.out
										.println("Please enter hotel id to retrieve guests list");
								String hotelId = scanner3.next();
								list = service.retrieveGuestList(hotelId);
								System.out
										.println("-------------------------------");
								System.out.println("---Guest List---");
								for (BookingDetails b : list)

								{
									System.out.println("No of Adults : "
											+ b.getNoOfAdults()
											+ "\nNo of Children : "
											+ b.getNoOfChildren());
								}

							} else if (choice3 == 4) {
								ArrayList<BookingDetails> list = new ArrayList<BookingDetails>();
								System.out
										.println("Enter a date in dd/MM/yyyy format to retrieve booking details");
								String date = scanner3.next();

								DateTimeFormatter dtf = DateTimeFormatter
										.ofPattern("dd/MM/yyyy");
								LocalDate date1 = LocalDate.parse(date, dtf);
								list = service.retrieveBookings(date1);

								System.out
										.println("-------------------------------");
								System.out.println("---Booking Details---");
								for (BookingDetails b : list) {
									System.out
											.println("-------------------------------");
									System.out.println("Booking Id: "
											+ b.getBookingId() + "\nRoom Id: "
											+ b.getRoomId() + "\nUser Id: "
											+ b.getUserId() + "\nBooked From: "
											+ b.getBookedFrom()
											+ "\nBooked To: " + b.getBookedTo()
											+ "\nNo of Adults: "
											+ b.getNoOfAdults()
											+ "\nNo of Children: "
											+ b.getNoOfChildren()
											+ "\nAmount: " + b.getAmount());

								}
							}

							break;
						case 4:
							System.exit(0);
						default:
							break;
						}
					}

				} else {
					System.out.println("Login Failed !!!Please Login Again");
				}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}

	}
}
