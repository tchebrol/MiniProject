package com.cg.miniproject.exception;

public class HotelException extends Exception {

	public HotelException() {
		// TODO Auto-generated constructor stub
	}

	public HotelException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}


}
