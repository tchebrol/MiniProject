package com.cg.miniproject.dao;

public interface IQueryMapper {
	String QUERY1 = "INSERT INTO Users values(userId_sequence.NEXTVAL,?,?,?,?,?,?,?)";
	String QUERY2 = "SELECT USER_NAME,PASSWORD from Users where USER_NAME=? AND PASSWORD=? AND Role=?";
	String QUERY3 = "insert into hotel(hotel_id,hotel_name,address,description,city,avg_rate_per_night) values (?,?,?,?,?,?)";
	String QUERY4 = "delete from hotel where hotel_id=?";
	String QUERY5 = "insert into roomdetails values (?,?,?,?,?,?)";
	String QUERY6 = "delete from roomdetails where room_id=?";
	String QUERY7 = "select b.* from bookingdetails b join roomdetails r on b.room_id=r.room_id join hotel h on h.hotel_id=r.hotel_id where h.hotel_id=?";
	String QUERY8 = "select * from bookingdetails where booked_from<=to_date(?,'YYYY-MM-DD') and booked_to>=to_date(?,'YYYY-MM-DD')";
	String QUERY9 = "select city,hotel_name,hotel_id from Hotel";
	String QUERY10 = "select hotel_id,room_id,room_no,room_type,per_night_rate,availability from RoomDetails where hotel_id = ? and availability='A'";
	String QUERY11 = "select per_night_rate from RoomDetails where room_id=?";
	String QUERY12 = "insert into BookingDetails values(seq_booking.nextval,?,?,?,?,?,?,?)";
	String QUERY13 = "update roomdetails set availability='NA' where room_id=?";
	String QUERY14 = "select user_id from users where USER_NAME=? AND PASSWORD=? AND Role=? ";
	String QUERY15 = "select sum(no_of_adults),sum(no_of_children) from bookingdetails b join roomdetails r on b.room_id=r.room_id join hotel h on h.hotel_id=r.hotel_id where h.hotel_id=?";
	String QUERY16 = "select user_name from users where user_name = ?";
	String QUERY17 = "select user_id from bookingdetails where user_id=?";
}
