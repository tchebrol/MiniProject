package com.cg.miniproject.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;

public interface IHotelBookingDao {

public boolean login(User user);

public boolean register(User user);


public boolean addHotels(Hotel hotel);

public boolean deleteHotel(String id);

public boolean addRooms(RoomDetails roomDetails);

public boolean deleteRooms(String id);

public ArrayList<BookingDetails> retrieveBookings(String hotelId);

public ArrayList<BookingDetails> retrieveBookings(LocalDate d);


public ArrayList<Hotel> getHotelList();

public ArrayList<RoomDetails> getRoomDetails(String id);

public void insertBookingDetails(BookingDetails bookingDetails);
}
