package com.cg.miniproject.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.exception.HotelException;

public interface IHotelBookingDao {

	public boolean login(User user) throws HotelException;

	public boolean register(User user) throws HotelException;

	public boolean addHotels(Hotel hotel) throws HotelException;

	public boolean deleteHotel(String id) throws HotelException;

	public boolean addRooms(RoomDetails roomDetails) throws HotelException;

	public boolean deleteRooms(String id) throws HotelException;

	public ArrayList<BookingDetails> retrieveBookings(String hotelId)
			throws HotelException;

	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException;

	public ArrayList<Hotel> getHotelList() throws HotelException;

	public ArrayList<RoomDetails> getRoomDetails(String id)
			throws HotelException;

	public boolean insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException;

	public User fetchUserId(User user) throws HotelException;

	public boolean validateName(User user) throws HotelException;

	public ArrayList<BookingDetails> retrieveGuestList(String hotelId)
			throws HotelException;

	public boolean bookingStatus(BookingDetails details) throws HotelException;

	public boolean modifyHotel(Hotel hotel2) throws HotelException;

	public boolean modifyRoom(RoomDetails details) throws HotelException;

}
