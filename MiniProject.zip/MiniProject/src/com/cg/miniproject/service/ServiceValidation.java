package com.cg.miniproject.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ServiceValidation {
	
	public int validateMobNo(String mobNo){
		Pattern pattern = Pattern.compile("^[9876][0-9]{9}$");
		Matcher matcher = pattern.matcher(mobNo);

		if (!matcher.find()) {
			System.err.println("Enter a valid mobile number.");
			return 0;
		}
		return 1;
	}
	
	public int validatePhone(String phone){
		Pattern pattern = Pattern.compile("^[9876][0-9]{9}$");
		Matcher matcher = pattern.matcher(phone);

		if (!matcher.find()) {
			System.err.println("Enter a valid phone number.");
			return 0;
		}
		return 1;
	}
	
	public int validateEmail(String email){
		
		Pattern pattern = Pattern.compile("^[A-Za-z0-9]+[@]+[a-z]+[.]+[a-z]{1,4}");
		Matcher matcher = pattern.matcher(email);
		
		if (!matcher.find()) {
			System.err.println("Enter a valid email id.");
			return 0;
		}
		return 1;
		
	}

	public boolean validateHotelId(String id) {
		// TODO Auto-generated method stub
		boolean res = false;
		Pattern pattern=Pattern.compile("^[0-9]{4}$");
		Matcher matcher = pattern.matcher(id);
		if (matcher.find()) {
			res = true;
		}
		else {
			System.err.println("Please enter valid 4-digit hotel id");
		}
		//System.out.println(res);
		return res;
	}

	public boolean validateRoomId(String id) {
		// TODO Auto-generated method stub
		boolean res = false;
		Pattern pattern=Pattern.compile("^[0-9]{3}$");
		Matcher matcher = pattern.matcher(id);
		if (matcher.find()) {
			res = true;
		}
		else {
			System.err.println("Please enter valid 3-digit room id");
		}
		return res;
	}

	public boolean getRoomType(String name) {
		// TODO Auto-generated method stub
		boolean res = false;
		String[] arr = {"Standard non A/C room","Standard A/C room","Exceutive A/C room","Deluxe A/C room"};
		if (name.equals(arr[0])||name.equals(arr[1])||name.equals(arr[2])||name.equals(arr[3]))
			res = true;
		else 
			System.err.println("Please enter valid room type");
		return res;
	}

}


