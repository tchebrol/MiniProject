package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.dao.IHotelBookingDao;
import com.cg.miniproject.dao.HotelBookingDaoImpl;
import com.cg.miniproject.exception.HotelException;

public class HotelBookingServiceImpl implements IHotelBookingService {

	public boolean register(User user) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.register(user);
	}

	public boolean login(User user) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.login(user);

	}

	@Override
	public boolean addHotels(Hotel hotel) throws HotelException {

		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.addHotels(hotel);
	}

	@Override
	public boolean deleteHotel(String id) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.deleteHotel(id);

	}

	@Override
	public boolean addRooms(RoomDetails roomDetails) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.addRooms(roomDetails);
	}

	@Override
	public boolean deleteRoom(String id) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.deleteRooms(id);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId)
			throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.retrieveBookings(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date)
			throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.retrieveBookings(date);
	}

	public ArrayList<Hotel> getHotelList() throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.getHotelList();
	}

	public ArrayList<RoomDetails> getRoomDetails(String id)
			throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.getRoomDetails(id);
	}

	@Override
	public boolean insertBookingDetails(BookingDetails bookingDetails)
			throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.insertBookingDetails(bookingDetails);
	}

	@Override
	public User fetchUserId(User user) throws HotelException {

		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.fetchUserId(user);
	}

	@Override
	public boolean validateName(User user) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.validateName(user);
	}

	@Override
	public ArrayList<BookingDetails> retrieveGuestList(String hotelId)
			throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.retrieveGuestList(hotelId);
	}

	public boolean bookingStatus(BookingDetails details) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.bookingStatus(details);
	}

	@Override
	public boolean modifyHotel(Hotel hotel) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.modifyHotel(hotel);
	}

	@Override
	public boolean modifyRoom(RoomDetails details) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.modifyRoom(details);
	}

	@Override
	public boolean validateHotelId(Hotel hotel) throws HotelException {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.validateHotelId(hotel);
	}

}