package com.cg.miniproject.service;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.miniproject.bean.BookingDetails;
import com.cg.miniproject.bean.Hotel;
import com.cg.miniproject.bean.RoomDetails;
import com.cg.miniproject.bean.User;
import com.cg.miniproject.dao.IHotelBookingDao;
import com.cg.miniproject.dao.HotelBookingDaoImpl;

public class HotelBookingServiceImpl implements IHotelBookingService {

	public boolean register(User user) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		// System.out.println("register");
		return dao.register(user);
	}

	public boolean login(User user) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		// System.out.println("login");
		return dao.login(user);

	}

	@Override
	public boolean addHotels(Hotel hotel) {

		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.addHotels(hotel);
	}

	@Override
	public boolean deleteHotel(String id) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.deleteHotel(id);

	}

	@Override
	public boolean addRooms(RoomDetails roomDetails) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.addRooms(roomDetails);
	}

	@Override
	public boolean deleteRoom(String id) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.deleteRooms(id);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(String hotelId) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.retrieveBookings(hotelId);
	}

	@Override
	public ArrayList<BookingDetails> retrieveBookings(LocalDate date) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();

		return dao.retrieveBookings(date);
	}

	public ArrayList<Hotel> getHotelList() {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.getHotelList();
	}

	public ArrayList<RoomDetails> getRoomDetails(String id) {
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.getRoomDetails(id);
	}

	@Override
	public boolean insertBookingDetails(BookingDetails bookingDetails) {
		// TODO Auto-generated method stub
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.insertBookingDetails(bookingDetails);
	}

	@Override
	public User fetchUserId(User user) {
		
		IHotelBookingDao dao = new HotelBookingDaoImpl();
		return dao.fetchUserId(user);
	}

}